# 💳 Credit Card Fraud Detection

A real-time fraud detection app using Python, Machine Learning, and Streamlit.

## Features

- Upload credit card transaction CSVs
- Predict fraud with probabilities
- Interactive graphs and download option
- Real-time fraud detection with charts

## Run Locally

```bash
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```
